### Orders.jar 

A simple program demonstarting the use of the console
input and output in Java with classes and extended classes.

###Instructions to run Orders.jar###

1. Download the .jar file
2. Open a command prompt as Administrator
3. cd into the saved directory 	
	(ex. C:\Users\Tom\Desktop)
4.  Execute Orders.jar with the following command:
	java -jar Orders.jar
5. Follow thhe onscreen prompts for input.

###The program is very simple and is only for the demnonstration
of the Java Scanner input / output operation.

### The above instruction set is for Windows 10.
Adjust accordingly to your operating system###

### Future Enhancements
  
  # Include a GUI using swt for improved appearance.
  